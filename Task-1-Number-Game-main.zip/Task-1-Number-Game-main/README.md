# Task-1-Number-Game
1. Generate a random number within a specified range, such as 1 to 100. 2. Prompt the user to enter their guess for the generated number. 3. Compare the user's guess with the generated number and provide feedback on whether the guess is correct, too high, or too low.  that type of 7 task
