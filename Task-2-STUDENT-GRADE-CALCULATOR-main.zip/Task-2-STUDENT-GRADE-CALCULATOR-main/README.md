# Task-2-STUDENT-GRADE-CALCULATOR
Input: Take marks obtained (out of 100) in each subject. Calculate Total Marks: Sum up the marks obtained in all subjects. Calculate Average Percentage: Divide the total marks by the total number of subjects to get the average percentage. Grade Calculation: Assign grades based on the average percentage achieved. 
